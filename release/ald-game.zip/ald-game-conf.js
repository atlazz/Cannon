exports.app_key = "b37d9400b8b494b067a438eba4573926"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置